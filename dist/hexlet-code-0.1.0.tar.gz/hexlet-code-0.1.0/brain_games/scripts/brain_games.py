def main():
    print("Welcome to the Brain Games!")
